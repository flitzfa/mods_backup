<h1 align=center>Terra Overworld Config</h1>

Default overworld configuration for Terra 6.0+. 

See the main Terra repository [here](https://github.com/PolyhedralDev/Terra).
